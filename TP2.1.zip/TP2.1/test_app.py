# Générer des tests unitaires avec pytest pour add_task, toggle_task, delete_task
import pytest
from app import Task, TaskService, TaskNotFoundError  
import os
TEST_TASKS_FILE = "test_tasks.json"
@pytest.fixture
def task_service():
    # Préparer un environnement de test avec un fichier de tâches temporaire
    if os.path.exists(TEST_TASKS_FILE):
        os.remove(TEST_TASKS_FILE)
    service = TaskService()
    yield service
    if os.path.exists(TEST_TASKS_FILE):
        os.remove(TEST_TASKS_FILE)


def test_add_task(task_service: TaskService):
    """
    Test creating a new task and verifying its properties.
    
    Verifies that:
    - A task is created with the correct title
    - The task has an assigned ID (1)
    - The task is initially marked as not done
    - The created task appears in the list of all tasks
    - The task list contains exactly one task with the correct title
    
    Args:
        task_service: Fixture providing the task service instance for testing.
    """
    task = task_service.create_task("Test Task")
    assert task.id == 1
    assert task.title == "Test Task"
    assert not task.done
    tasks = task_service.get_all_tasks()
    assert len(tasks) == 1
    assert tasks[0].title == "Test Task"
    task_service.delete_task_by_id(task.id)


def test_delete_task(task_service: TaskService):
    task = task_service.create_task("Test Task")
    tasks = task_service.get_all_tasks()
    assert len(tasks) == 1
    task_service.delete_task_by_id(task.id)
    tasks = task_service.get_all_tasks()
    assert len(tasks) == 0

def test_toggle_task(task_service: TaskService):
    task = task_service.create_task("Test Task")
    assert not task.done
    toggled_task = task_service.toggle_task_status(task.id)
    assert toggled_task.done
    toggled_task = task_service.toggle_task_status(task.id)
    assert not toggled_task.done
    task_service.delete_task_by_id(task.id)





def test_toggle_nonexistent_task(task_service: TaskService):
    with pytest.raises(TaskNotFoundError):
        task_service.toggle_task_status(999)


def test_delete_nonexistent_task(task_service: TaskService):
    with pytest.raises(TaskNotFoundError):
        task_service.delete_task_by_id(999)

from unittest.mock import MagicMock, patch
from fastapi import HTTPException
from app import  Task
# Standalone MagicMock fixtures
@pytest.fixture
def mock_task_create():
    """Fixture returning a MagicMock Task"""
    mock = MagicMock(spec=Task)
    mock.title = "Tâche par défaut"
    return mock


@pytest.fixture
def mock_task_response():
    """Fixture returning a MagicMock Task response"""
    mock = MagicMock(spec=Task)
    mock.id = 1
    mock.title = "Tâche créée"
    mock.done = False
    return mock


@pytest.fixture
def mock_create_task_function():
    """Fixture that mocks the entire create_task function"""
    mock_func = MagicMock()
    
    def side_effect(task: Task):
        if not task.title or task.title.strip() == "":
            raise HTTPException(
                status_code=422,
                detail="Le titre de la tâche ne peut pas être vide"
            )
        
        response = MagicMock(spec=Task)
        response.id = 1
        response.title = task.title
        response.done = False
        return response
    
    mock_func.side_effect = side_effect
    return mock_func


# Example: Testing with FastAPI TestClient and MagicMock
def test_with_mocked_function(mock_create_task_function):
    """Example using the mocked function fixture"""
    # Test successful creation
    task_input = MagicMock(spec=Task)
    task_input.title = "Nouvelle tâche"
    
    result = mock_create_task_function(task_input)
    
    assert result.title == "Nouvelle tâche"
    assert result.done is False
    mock_create_task_function.assert_called_once_with(task_input)


def test_mock_function_empty_title(mock_create_task_function):
    """Test mocked function with empty title"""
    task_input = MagicMock(spec=Task)
    task_input.title = ""
    
    with pytest.raises(HTTPException) as exc_info:
        mock_create_task_function(task_input)
    
    assert exc_info.value.status_code == 422


