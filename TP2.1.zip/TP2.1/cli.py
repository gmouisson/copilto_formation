# Créer une interface CLI avec argparse:
# commandes: add "title", list, toggle "id", delete "id"
# Afficher un format lisible: [id] title - DONE/NOT DONE
import argparse
from app import TaskService, TaskNotFoundError
def main():
    parser = argparse.ArgumentParser(description="Gestionnaire de tâches CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Commande add
    add_parser = subparsers.add_parser("add", help="Ajouter une nouvelle tâche")
    add_parser.add_argument("title", type=str, help="Le titre de la tâche")

    # Commande list
    list_parser = subparsers.add_parser("list", help="Lister toutes les tâches")

    # Commande toggle
    toggle_parser = subparsers.add_parser("toggle", help="Bascule le statut d'une tâche")
    toggle_parser.add_argument("id", type=int, help="L'ID de la tâche à basculer")

    # Commande delete
    delete_parser = subparsers.add_parser("delete", help="Supprimer une tâche")
    delete_parser.add_argument("id", type=int, help="L'ID de la tâche à supprimer")

    args = parser.parse_args()
    service = TaskService()

    if args.command == "add":
        task = service.create_task(args.title)
        print(f"Tâche ajoutée: [{task.id}] {task.title} - {'DONE' if task.done else 'NOT DONE'}")
    elif args.command == "list":
        tasks = service.get_all_tasks()
        for task in tasks:
            print(f"[{task.id}] {task.title} - {'DONE' if task.done else 'NOT DONE'}")
    elif args.command == "toggle":
        try:
            task = service.toggle_task_status(args.id)
            print(f"Tâche mise à jour: [{task.id}] {task.title} - {'DONE' if task.done else 'NOT DONE'}")
        except TaskNotFoundError as e:
            print(e)
    elif args.command == "delete":
        try:
            service.delete_task_by_id(args.id)
            print(f"Tâche avec ID {args.id} supprimée.")
        except TaskNotFoundError as e:
            print(e)
        
if __name__ == "__main__":
    main()
   