# Implémenter un stockage JSON pour les tâches dans "tasks.json"
# Fonctions: load_tasks() -> list[dict], save_tasks(tasks: list[dict]) -> None
# Gérer le cas où le fichier n'existe pas encore
import json
import os   
TASKS_FILE = "tasks.json"
def load_tasks() -> list[dict]:
    """
    Charge les tâches depuis le fichier JSON.

    Returns:
        list[dict]: La liste des tâches chargées.

    Exemple:
        >>> tasks = load_tasks()
        >>> print(tasks)
        [{'id': 1, 'title': 'Acheter du lait', 'done': False}]
    """
    if not os.path.exists(TASKS_FILE):
        print("Le fichier de tâches n'existe pas. Retourne une liste vide.")
        return []
    with open(TASKS_FILE, "r") as file:
        return json.load(file)
    

def save_tasks(tasks: list[dict]) -> None:
    """
    Sauvegarde les tâches dans le fichier JSON.

    Args:
        tasks (list[dict]): La liste des tâches à sauvegarder.

    Exemple:
        >>> tasks = [{'id': 1, 'title': 'Acheter du lait', 'done': False}]
        >>> save_tasks(tasks)
    """
    with open(TASKS_FILE, "w") as file:
        json.dump(tasks, file, indent=4)
