# Générer un guide d'utilisation pour le gestionnaire de tâches CLI:
# installation, commandes, exemples, et bonnes pratiques de prompts Copilot 
Bienvenue dans le guide d'utilisation du gestionnaire de tâches en ligne de commande (CLI) avec l'assistance de GitHub Copilot. Ce guide vous aidera à installer le gestionnaire de tâches, à comprendre les commandes disponibles, à voir des exemples d'utilisation, et à adopter de bonnes pratiques pour maximiser l'efficacité de vos prompts avec Copilot.
## Installation
1. **Prérequis**:
   - Assurez-vous d'avoir Python 3.x installé sur votre machine.
   - Installez GitHub Copilot dans votre éditeur de code préféré (par exemple, Visual Studio Code).
2. **Cloner le dépôt**:
   ```bash
   git clone https://github.com/username/repository.git
   ```
3. **Installer les dépendances**:
   ```bash
   cd repository
   pip install -r requirements.txt
   ```
4. **Configurer l'environnement** (facultatif mais recommandé):
   - Créez un fichier `.env` à la racine du projet pour les variables sensibles.
   - Exemple de contenu:
     ```
     DATABASE_URL=sqlite:///tasks.db
     SECRET_KEY=your_secret_key
     ```

## Lancer l'application

- Afficher l'aide générale:
  ```bash
  taskmgr --help
  ```
- Exemple avec version:
  ```bash
  taskmgr --version
  ```

## Commandes principales

- Ajouter une tâche
  ```bash
  taskmgr add "Titre de la tâche" --due "2025-12-01" --priority high --note "Détails..."
  ```
- Lister les tâches
  ```bash
  taskmgr list
  taskmgr list --status pending
  taskmgr list --sort due
  ```
- Marquer comme terminée
  ```bash
  taskmgr done <task_id>
  ```
- Supprimer une tâche
  ```bash
  taskmgr remove <task_id>
  ```
- Modifier une tâche
  ```bash
  taskmgr edit <task_id> --title "Nouveau titre" --priority low
  ```
- Importer / exporter
  ```bash
  taskmgr export tasks.json
  taskmgr import tasks.json
  ```
- Effacer toutes les tâches (avec confirmation)
  ```bash
  taskmgr clear --confirm
  ```

## Exemples pratiques

- Ajouter une tâche rapide
  ```bash
  taskmgr add "Préparer la réunion hebdo" --due "2025-11-30"
  ```
- Lister les tâches à haute priorité
  ```bash
  taskmgr list --priority high
  ```
- Rechercher une tâche contenant un mot-clé
  ```bash
  taskmgr list --filter "réunion"
  ```

## Fichier de configuration (exemple)

Un fichier ~/.taskmgr/config.yml ou ./taskmgr.yml peut contenir:
```yaml
default_priority: medium
date_format: "%Y-%m-%d"
storage_path: "~/.taskmgr/tasks.json"
timezone: "Europe/Paris"
```

## Bonnes pratiques CLI

- Utiliser des identifiants courts pour les commandes récurrentes (alias dans ~/.bashrc ou ~/.zshrc).
  ```bash
  alias tm='taskmgr'
  ```
- Toujours sauvegarder/exporter avant d'importer ou de faire un clear.
- Préférer les dates ISO (YYYY-MM-DD) pour la portabilité.
- Utiliser des scripts ou Makefile pour automatiser les flows répétitifs.

## Bonnes pratiques pour rédiger des prompts Copilot (optimiser suggestions)

1. Soyez spécifique
   - Décrivez l'objectif, contraintes et le format attendu.
   - Ex : "Génère une fonction Python qui prend une liste de tâches (dicts) et renvoie les 5 tâches les plus urgentes triées par date d'échéance."

2. Fournissez un contexte minimal mais suffisant
   - Incluez les signatures de fonctions, exemples d'entrée/sortie, ou extraits de code existant.

3. Demandez des tests
   - "Génère aussi des tests unitaires pytest pour couvrir cas normal et cas d'erreur."

4. Itérez
   - Acceptez une suggestion, ajustez le prompt avec retours, puis régénérez.

5. Contraintes de style
   - Indiquez le style de code (PEP8, type hints, docstrings) et la version Python.

Exemples de prompt optimisés
- "Écris une fonction Python nommée get_next_tasks(tasks, n=5) -> List[Dict] avec type hints. tasks est une liste de dicts contenant 'id','title','due' (YYYY-MM-DD), 'priority'. Retourne les n tâches non terminées triées par priorité puis date. Ajoute docstring et tests pytest."
- "Convertis le parser argparse existant en click et fournis les modifications nécessaires (fichier modifié et tests)."

## Dépannage rapide

- Erreur d'import après installation:
  ```bash
  pip install -e .
  ```
- Problèmes de permission sur stockage:
  ```bash
  chmod 600 ~/.taskmgr/tasks.json
  ```
- Logs et verbosité:
  ```bash
  taskmgr --verbose list
  ```

## Tests

- Commande exemple pour lancer la suite de tests:
  ```bash
  pytest -q
  ```

## Contribution

- Fork -> Branche -> Pull Request
- Respecter le style de code du projet et ajouter des tests pour toute fonctionnalité nouvelle

## Licence

Indiquez la licence du projet (ex: MIT) dans LICENSE.


