# Créer une classe Task(id: int, title: str, done: bool=False)
# Créer une classe TaskService pour gérer CRUD: add_task, list_tasks, toggle_task,delete_task
# Ajouter des docstrings et exemples d'usage
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class Task:
    """Représente une tâche simple."""

    id: int
    title: str
    done: bool = False


class TaskNotFoundError(Exception):
    """Exception levée lorsque la tâche demandée est introuvable."""


class TaskRepository:
    """Couche d'abstraction pour le stockage des tâches.

    Utilise le module `storage` (JSON) pour charger et sauvegarder les tâches.
    """

    def load_all(self) -> List[Task]:
        import storage

        raw = storage.load_tasks()
        return [Task(item['id'], item['title'], item.get('done', False)) for item in raw]

    def save_all(self, tasks: List[Task]) -> None:
        from storage import save_tasks

        data = [{'id': t.id, 'title': t.title, 'done': t.done} for t in tasks]
        save_tasks(data)


class TaskService:
    """Service de haut niveau gérant la logique métier des tâches.

    Sépare les responsabilités: la persistance est déléguée à
    `TaskRepository`. Les méthodes ont des noms explicites et
    lèvent `TaskNotFoundError` lorsque l'identifiant est introuvable.
    """

    def __init__(self, repository: Optional[TaskRepository] = None) -> None:
        self.repository: TaskRepository = repository or TaskRepository()
        self.tasks: List[Task] = self.repository.load_all()
        self.next_id: int = (max((t.id for t in self.tasks), default=0) + 1)

    def create_task(self, title: str) -> Task:
        """Crée et persiste une nouvelle tâche.

        Args:
            title: Le titre de la tâche.

        Returns:
            La tâche créée.
        """
        task = Task(self.next_id, title, False)
        self.tasks.append(task)
        self.next_id += 1
        self.repository.save_all(self.tasks)
        return task

    def get_all_tasks(self) -> List[Task]:
        """Retourne la liste des tâches en mémoire (copie)."""
        return list(self.tasks)

    def get_task_by_id(self, task_id: int) -> Task:
        """Retourne la tâche correspondant à `task_id` ou lève `TaskNotFoundError`."""
        for t in self.tasks:
            if t.id == task_id:
                return t
        raise TaskNotFoundError(f"Tâche avec id={task_id} introuvable")

    def toggle_task_status(self, task_id: int) -> Task:
        """Bascule le statut `done` d'une tâche et persiste le changement.

        Returns la tâche mise à jour.
        """
        task = self.get_task_by_id(task_id)
        task.done = not task.done
        self.repository.save_all(self.tasks)
        return task

    def delete_task_by_id(self, task_id: int) -> None:
        """Supprime la tâche identifiée par `task_id` ou lève `TaskNotFoundError`."""
        for i, t in enumerate(self.tasks):
            if t.id == task_id:
                del self.tasks[i]
                self.repository.save_all(self.tasks)
                return
        raise TaskNotFoundError(f"Tâche avec id={task_id} introuvable")

    def save(self) -> None:
        """Persiste l'état courant des tâches (méthode de compatibilité)."""
        self.repository.save_all(self.tasks)